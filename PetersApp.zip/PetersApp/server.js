const path = require('path');
const http = require('http');
const express = require('express');
const socketio = require('socket.io');
const formatMessage = require('./utils/messages');
const { userJoin, getCurrentUser, userLeave, getRoomUsers } = require('./utils/users');

const app = express();
const server = http.createServer(app);
const io = socketio(server);

// Lägg till statisk mapp 
app.use(express.static(path.join(__dirname, 'public')));
 
const AdminPeter = 'skolchat bot';
// Kör när klient får koppling
io.on('connection', socket => {
    socket.on('joinRoom', ({ username, room }) => {
   const user = userJoin(socket.id, username, room);
        socket.join(user.room);
    // För en singel klient (Nuvarande användare)
    socket.emit('message', formatMessage(AdminPeter, 'Välkommen till Peters skolchat'));

    // Sänder när användare tillkopplas (till alla klienter)
    socket.broadcast.to(user.room).emit('message', formatMessage(AdminPeter,`${user.username} har anslutit till chaten`));
    
    // Skicka ut användar & rum info
    io.to(user.room).emit('roomUsers', {room: user.room, users: getRoomUsers(user.room)
    });
});



//Kontrollera efter chat meddelande
socket.on('chatMessage', (msg) => {
    const user = getCurrentUser(socket.id);
io.to(user.room).emit('message', formatMessage(user.username, msg)); // så att den skickas till alla
});

// Körs när klient frånkopplas
socket.on ('disconnect', () =>{
    const user = userLeave(socket.id);

    if(user){
        io.to(user.room).emit('message', formatMessage(AdminPeter, `${user.username} har lämnat chaten`));


        // Skicka ut användare och rum information
    io.to(user.room).emit('roomUsers', {room: user.room, users: getRoomUsers(user.room)
    });
    
    }
    
    }); 
});


const PORT = 3000 || process.env.PORT; 
//const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`server körs på port ${PORT}`)); 

