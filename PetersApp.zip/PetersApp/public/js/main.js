const chatForm = document.getElementById('chat-form');
const chatMessages = document.querySelector('.chat-messages');
const roomName = document.getElementById('room-name');
const userList = document.getElementById('users');

//Hämta användarnamn och rum från url
const {username, room} = Qs.parse(location.search, {
    ignoreQueryPrefix: true
});

const socket = io(); // Tillgång till script i chat.html (rad 59)

// Gå med chat rum
socket.emit('joinRoom',{username, room});

//Hämta rum & användare
socket.on('roomUsers', ({ room, users }) => {
    outputRoomName(room);
    outputUsers(users);
});
//Meddelande från servern
socket.on('message', message => {
    console.log(message);
    outputMessage(message); // så att den inte bara hamnar i console

//scrolla ner varje gång meddelande
chatMessages.scrollTop = chatMessages.scrollHeight;
});

//Skicka in meddelande
chatForm.addEventListener('submit', e => {
e.preventDefault();

//Hämta meddelande text
const msg = e.target.elements.msg.value;//hämtas från chat.html (rad 49)
//sänd meddelande till servern
socket.emit('chatMessage', msg);


// rensa input
e.target.elements.msg.value = '';
e.target.elements.msg.focus();
});

// Meddelande som hamnar på "output" manipuleras här
function outputMessage(message) {
const div = document.createElement('div');
div.classList.add('message');
div.innerHTML = `<p class="meta">${message.username}<span>${message.time}</span></p>
<p class="text">
    ${message.text}
</p>`;
document.querySelector('.chat-messages').appendChild(div);
}

//Lägg till rum namn i "DOM"
function outputRoomName(room) {
roomName.innerText = room;
}
// Lägg till användare i "DOM"
function outputUsers(users) {
    userList.innerHTML = `${users.map(user =>`<li>${user.username}</li>`).join('')}`;
}